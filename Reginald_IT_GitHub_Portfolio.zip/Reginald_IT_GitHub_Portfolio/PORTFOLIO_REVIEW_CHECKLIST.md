# Portfolio Review Checklist

Before publishing to GitHub:

- [ ] Replace any remaining example values if desired
- [ ] Confirm no real company paths are present
- [ ] Confirm no passwords or credentials are present
- [ ] Confirm no confidential documents are present
- [ ] Review screenshots before uploading
- [ ] Test PowerShell scripts in a lab
- [ ] Check README formatting
- [ ] Add GitHub profile link to CV after publishing
