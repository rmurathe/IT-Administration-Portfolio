# IT Asset Register

| Asset ID | Device | Serial No. | User | Location | Status | Date |
|---|---|---|---|---|---|---|
| IT-0001 | Desktop PC | SAMPLE | User | Office | Active | YYYY-MM-DD |
