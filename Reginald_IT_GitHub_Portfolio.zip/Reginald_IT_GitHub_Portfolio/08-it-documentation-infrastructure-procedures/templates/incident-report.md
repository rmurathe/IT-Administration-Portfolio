# IT Incident Report

**Incident ID:**  
**Date:**  
**Reported By:**  
**Affected Device/System:**  
**Problem:**  
**Impact:**  
**Investigation:**  
**Root Cause:**  
**Resolution:**  
**Verification:**  
**Technician:**
