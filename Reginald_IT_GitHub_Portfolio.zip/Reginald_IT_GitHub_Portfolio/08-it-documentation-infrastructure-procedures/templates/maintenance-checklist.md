# IT Maintenance Checklist

- [ ] Check system updates
- [ ] Check storage capacity
- [ ] Review important alerts
- [ ] Verify backup status
- [ ] Check network equipment
- [ ] Check printers/peripherals
- [ ] Review asset changes
- [ ] Record maintenance findings
