# Backup Verification

Verify:

- Backup job completed
- Log has no critical errors
- Expected files exist
- Destination storage is available
- A test restore is periodically performed according to the organization's recovery plan

A backup is only useful if restoration is possible.
