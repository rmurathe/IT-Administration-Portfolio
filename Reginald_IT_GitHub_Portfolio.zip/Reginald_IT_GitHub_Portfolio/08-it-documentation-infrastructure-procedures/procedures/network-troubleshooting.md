# Network Troubleshooting Procedure

Start with:

```powershell
Get-NetAdapter
Get-NetIPConfiguration
ipconfig /all
```

Then test gateway, DNS and the required service.
