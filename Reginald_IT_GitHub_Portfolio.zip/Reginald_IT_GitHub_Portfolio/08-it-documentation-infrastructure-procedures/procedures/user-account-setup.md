# User Account Setup

Document:

- User identity
- Department
- Required applications
- Required access groups
- Device assignment
- Approval
- Completion date

Never record passwords in the procedure or asset register.
