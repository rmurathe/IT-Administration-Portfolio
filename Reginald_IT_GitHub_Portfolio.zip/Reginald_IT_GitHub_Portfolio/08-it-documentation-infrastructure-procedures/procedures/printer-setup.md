# Printer Setup

1. Identify printer model.
2. Connect USB/network as required.
3. Install approved driver.
4. Configure printer.
5. Print a test page.
6. Confirm application printing.
7. Document IP/asset details where appropriate.
