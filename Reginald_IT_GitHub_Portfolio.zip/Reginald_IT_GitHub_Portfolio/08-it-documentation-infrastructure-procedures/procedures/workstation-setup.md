# Workstation Setup Procedure

1. Confirm hardware and asset information.
2. Install/verify operating system.
3. Apply approved updates.
4. Install required applications.
5. Configure network access.
6. Apply security settings.
7. Test peripherals.
8. Confirm user access.
9. Record the completed setup.
