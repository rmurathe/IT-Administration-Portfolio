# Virtual Machine Setup

Typical lab VMs:

- DC01
- CLIENT01
- CLIENT02
- FILE01

Assign resources according to the host computer's capacity and the operating system requirements.

Take a clean snapshot before major lab changes if appropriate.
