# VM Troubleshooting

Check:

1. VM power state
2. Virtual NIC connected status
3. Virtual network selected
4. Guest IP configuration
5. DNS
6. Gateway
7. Windows Firewall
8. Service status
