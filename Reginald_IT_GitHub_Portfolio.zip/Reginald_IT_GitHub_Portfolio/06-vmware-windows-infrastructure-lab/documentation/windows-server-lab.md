# Windows Server Lab

Example services:

- AD DS
- DNS
- DHCP
- File Services

Keep infrastructure services logically documented and use fixed addresses for servers where required by the design.
