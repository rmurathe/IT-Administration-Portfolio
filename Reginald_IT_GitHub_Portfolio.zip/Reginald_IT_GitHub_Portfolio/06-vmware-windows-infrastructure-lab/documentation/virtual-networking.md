# Virtual Networking

## NAT

Useful when VMs need outbound connectivity through the host.

## Bridged

Places the VM on the same physical network as the host.

## Host-only

Useful for isolated labs where VMs communicate with the host and each other without direct external access.
