# Screenshots

Place sanitized screenshots here if desired.

Before publishing, remove or obscure:

- usernames
- internal IP addresses
- server names
- company names
- email addresses
- credentials
- customer information
