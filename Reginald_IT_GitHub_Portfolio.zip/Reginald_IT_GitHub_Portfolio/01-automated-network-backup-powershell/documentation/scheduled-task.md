# Scheduled Task

A Windows Scheduled Task can execute `backup.ps1` automatically.

## Example Action

Program:

```text
powershell.exe
```

Arguments:

```text
-NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\backup.ps1"
```

Use an appropriate service or administrative account for the environment and protect stored credentials.

## Verification

```powershell
Get-ScheduledTask
Get-ScheduledTaskInfo -TaskName "Shared Data Backup"
```
