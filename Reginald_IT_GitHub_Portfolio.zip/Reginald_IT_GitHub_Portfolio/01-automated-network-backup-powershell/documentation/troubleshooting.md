# Backup Troubleshooting

## Check the Source

```powershell
Test-Path "\\FILESERVER\SharedData"
```

## Check the Destination

```powershell
Test-Path "D:\Backups\SharedData"
```

## Review the Log

```powershell
Get-Content "D:\Backups\Logs\backup.log" -Tail 30
```

## Robocopy Exit Codes

Robocopy uses exit codes where values below 8 generally indicate that the operation did not encounter a fatal error. Always review the log and environment rather than relying only on the exit code.

## Common Causes

- Server unavailable
- SMB connectivity problem
- Insufficient permissions
- Destination storage unavailable
- File locking
- Scheduled Task account permissions
