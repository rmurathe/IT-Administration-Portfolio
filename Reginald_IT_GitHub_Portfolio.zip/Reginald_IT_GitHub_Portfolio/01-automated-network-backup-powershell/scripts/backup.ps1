# Automated Network Backup
$Source = "\\FILESERVER\SharedData"
$Destination = "D:\Backups\SharedData"
$LogFile = "D:\Backups\Logs\backup.log"

New-Item -ItemType Directory -Force -Path $Destination | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path $LogFile) | Out-Null

$Options = @(
    "/E",
    "/Z",
    "/FFT",
    "/R:3",
    "/W:5",
    "/COPY:DAT",
    "/DCOPY:T",
    "/NP",
    "/LOG+:$LogFile"
)

Write-Host "Starting backup..."
Write-Host "Source: $Source"
Write-Host "Destination: $Destination"

robocopy $Source $Destination @Options

$ExitCode = $LASTEXITCODE
Write-Host "Robocopy exit code: $ExitCode"

if ($ExitCode -lt 8) {
    Write-Host "Backup completed successfully."
} else {
    Write-Host "Backup completed with errors."
    exit $ExitCode
}
