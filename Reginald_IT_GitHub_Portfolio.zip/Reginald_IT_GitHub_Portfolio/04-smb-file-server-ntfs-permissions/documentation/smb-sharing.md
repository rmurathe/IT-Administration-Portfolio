# SMB Sharing

Create a share:

```powershell
New-SmbShare -Name "CompanyData" -Path "D:\CompanyData"
```

Review:

```powershell
Get-SmbShare
Get-SmbShareAccess -Name "CompanyData"
```
