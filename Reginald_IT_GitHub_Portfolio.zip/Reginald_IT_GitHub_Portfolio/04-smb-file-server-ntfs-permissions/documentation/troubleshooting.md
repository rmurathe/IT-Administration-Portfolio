# File Share Troubleshooting

Check:

```powershell
Test-Path "\\FILESERVER\CompanyData"
Get-SmbShare
Get-SmbShareAccess -Name "CompanyData"
Get-Acl "D:\CompanyData"
```

Also verify network connectivity, Windows Firewall, SMB availability and the user's effective permissions.
