# Access Control

Recommended approach:

1. Create security groups.
2. Assign users to groups.
3. Grant groups access to folders.
4. Use inheritance where appropriate.
5. Document exceptions.
6. Test with a normal user account.
