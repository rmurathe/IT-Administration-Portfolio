# NTFS Permissions

Common rights include:

- Read
- Read & Execute
- Write
- Modify
- Full Control
- Delete

Remember that Modify includes Delete. Custom deny rules must be tested carefully because deny entries and inheritance can produce unexpected effective permissions.
