$Path = "D:\CompanyData"

Write-Host "===== SMB SHARES ====="
Get-SmbShare | Select-Object Name, Path

Write-Host "`n===== SHARE ACCESS ====="
Get-SmbShareAccess -Name "CompanyData" -ErrorAction SilentlyContinue

Write-Host "`n===== NTFS ACL ====="
Get-Acl $Path | Select-Object -ExpandProperty Access
