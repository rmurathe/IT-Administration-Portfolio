# Script Usage

Review the script first:

```powershell
Get-Content .\script-name.ps1
```

Run:

```powershell
.\script-name.ps1
```

For production environments, follow organizational change-control and execution-policy requirements.
