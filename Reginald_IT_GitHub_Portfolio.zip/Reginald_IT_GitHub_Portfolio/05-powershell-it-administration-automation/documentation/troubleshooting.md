# PowerShell Troubleshooting

Common issues:

- Execution policy restrictions
- Missing Windows modules
- Insufficient privileges
- Service names differing between editions
- Remote-management restrictions

Check PowerShell version:

```powershell
$PSVersionTable
```
