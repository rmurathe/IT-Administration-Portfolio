Get-LocalUser |
Select-Object Name, Enabled, LastLogon, PasswordRequired

Get-LocalGroupMember -Group "Administrators"
