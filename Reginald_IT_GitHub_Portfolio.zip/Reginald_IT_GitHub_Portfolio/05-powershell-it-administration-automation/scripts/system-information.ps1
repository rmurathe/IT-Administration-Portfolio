Write-Host "===== SYSTEM INFORMATION ====="

Get-CimInstance Win32_ComputerSystem |
Select-Object Manufacturer, Model, Domain, NumberOfLogicalProcessors

Write-Host "`n===== OPERATING SYSTEM ====="

Get-CimInstance Win32_OperatingSystem |
Select-Object Caption, Version, BuildNumber, LastBootUpTime
