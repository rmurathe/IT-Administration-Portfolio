$Services = @("Spooler", "LanmanServer", "LanmanWorkstation", "WinRM")

foreach ($ServiceName in $Services) {
    $Service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue

    if ($Service) {
        [PSCustomObject]@{
            Service = $Service.Name
            Status = $Service.Status
            StartType = $Service.StartType
        }
    } else {
        Write-Warning "Service not found: $ServiceName"
    }
}
