Write-Host "===== NETWORK CONFIGURATION ====="
Get-NetIPConfiguration

Write-Host "`n===== NETWORK ADAPTERS ====="
Get-NetAdapter |
Select-Object Name, Status, LinkSpeed, MacAddress

Write-Host "`n===== DEFAULT GATEWAY TEST ====="

$Gateway = (Get-NetIPConfiguration |
    Where-Object {$_.IPv4DefaultGateway} |
    Select-Object -First 1).IPv4DefaultGateway.NextHop

if ($Gateway) {
    Test-Connection $Gateway -Count 2
} else {
    Write-Host "Default gateway not detected."
}
