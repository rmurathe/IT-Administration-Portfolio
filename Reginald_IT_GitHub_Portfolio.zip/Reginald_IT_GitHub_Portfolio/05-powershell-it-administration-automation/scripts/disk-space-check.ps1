$Threshold = 15

Get-Volume |
Where-Object { $_.DriveLetter -and $_.Size -gt 0 } |
ForEach-Object {

    $FreePercent = ($_.SizeRemaining / $_.Size) * 100

    [PSCustomObject]@{
        Drive = "$($_.DriveLetter):"
        SizeGB = [math]::Round($_.Size / 1GB, 2)
        FreeGB = [math]::Round($_.SizeRemaining / 1GB, 2)
        FreePercent = [math]::Round($FreePercent, 1)
    }

    if ($FreePercent -lt $Threshold) {
        Write-Warning "$($_.DriveLetter): has only $([math]::Round($FreePercent,1))% free space."
    }
}
