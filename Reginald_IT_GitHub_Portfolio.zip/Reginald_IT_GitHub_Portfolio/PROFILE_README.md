# REGINALD MURATHE MUNYUA

**IT Support | IT Infrastructure | Systems & Network Support**

## About Me

IT Support and Infrastructure professional with extensive hands-on experience supporting computer systems, users, networks, hardware, software and IT infrastructure.

## Areas of Expertise

- IT Support & Helpdesk
- Windows Administration
- Windows Server
- Active Directory
- DNS & DHCP
- TCP/IP Networking
- SMB File Sharing
- NTFS Permissions
- PowerShell
- Backup & Recovery
- VMware Virtualization
- Hardware & Software Troubleshooting
- Printer Support
- CCTV & Access Control
- IT Documentation

## Portfolio Projects

1. Automated Network Backup with PowerShell and Robocopy
2. Windows Server & Active Directory Administration Lab
3. Network Administration & Troubleshooting Lab
4. SMB File Server & NTFS Permissions
5. PowerShell IT Administration & Automation
6. VMware Windows Infrastructure Lab
7. Windows Desktop Troubleshooting & IT Support
8. IT Documentation & Infrastructure Procedures

## Approach

My projects focus on practical IT administration, troubleshooting, automation, documentation, security awareness and infrastructure support.

> **Portfolio note:** Examples use fictional/sanitized names, addresses, domains and paths. No confidential company information is included.
