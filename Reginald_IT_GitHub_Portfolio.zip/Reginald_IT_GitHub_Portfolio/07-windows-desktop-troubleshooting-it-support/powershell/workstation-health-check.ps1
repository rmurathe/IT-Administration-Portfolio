Write-Host "===== WORKSTATION HEALTH CHECK ====="

Get-CimInstance Win32_ComputerSystem |
Select-Object Manufacturer, Model, Domain

Get-CimInstance Win32_OperatingSystem |
Select-Object Caption, Version, BuildNumber, LastBootUpTime

Get-Volume |
Where-Object { $_.DriveLetter -and $_.Size -gt 0 } |
Select-Object DriveLetter,
    @{Name="SizeGB";Expression={[math]::Round($_.Size / 1GB,2)}},
    @{Name="FreeGB";Expression={[math]::Round($_.SizeRemaining / 1GB,2)}}

Get-NetIPConfiguration
Get-NetAdapter | Select-Object Name, Status, LinkSpeed

Get-Service |
Where-Object { $_.Name -in @("Spooler","wuauserv","LanmanWorkstation") } |
Select-Object Name, Status, StartType
