# Troubleshooting Methodology

Use evidence rather than assumptions. Record symptoms, tests, results and actions.

Example:

```text
Problem -> Investigation -> Test -> Finding -> Fix -> Verification
```
