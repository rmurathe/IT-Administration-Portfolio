# Network Troubleshooting

```powershell
ipconfig /all
ping <gateway>
nslookup <hostname>
Test-NetConnection <host> -Port 445
```

Test one layer at a time and document the result.
