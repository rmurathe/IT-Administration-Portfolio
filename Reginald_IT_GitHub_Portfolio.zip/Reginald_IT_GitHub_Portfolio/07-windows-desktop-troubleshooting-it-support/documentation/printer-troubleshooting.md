# Printer Troubleshooting

Check the physical printer first, then connectivity, driver, queue and Print Spooler.

Useful command:

```powershell
Get-Service Spooler
```

Clear a stuck queue only after confirming that the affected jobs can be safely removed.
