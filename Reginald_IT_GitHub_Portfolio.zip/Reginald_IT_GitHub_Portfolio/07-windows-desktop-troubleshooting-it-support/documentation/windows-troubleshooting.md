# Windows Troubleshooting

Useful checks:

```powershell
Get-CimInstance Win32_OperatingSystem
Get-WinEvent -LogName System -MaxEvents 20
Get-Service
```

For system-file problems:

```text
sfc /scannow
DISM /Online /Cleanup-Image /RestoreHealth
```
