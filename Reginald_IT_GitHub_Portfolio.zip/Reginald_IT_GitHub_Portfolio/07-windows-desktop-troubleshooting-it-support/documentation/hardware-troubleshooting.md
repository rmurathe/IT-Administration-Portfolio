# Hardware Troubleshooting

Check:

- Power
- Cables
- RAM
- Storage health
- Device Manager
- BIOS/UEFI settings
- Temperature/airflow where relevant
- Known-good replacement components

Use safe handling procedures when working inside computers.
