# TCP/IP Troubleshooting

Check:

```powershell
Get-NetIPConfiguration
Get-NetAdapter
```

Then test connectivity progressively:

```text
Local adapter -> Gateway -> DNS -> Remote host -> Application/service
```
