# Troubleshooting Checklist

| Test | Purpose |
|---|---|
| Get-NetAdapter | Check adapter/link |
| Get-NetIPConfiguration | Check addressing |
| ping gateway | Check local routing |
| nslookup | Check DNS |
| Test-NetConnection | Check TCP port |
| Event Viewer | Check Windows events |

Document symptoms, tests performed, findings and final resolution.
