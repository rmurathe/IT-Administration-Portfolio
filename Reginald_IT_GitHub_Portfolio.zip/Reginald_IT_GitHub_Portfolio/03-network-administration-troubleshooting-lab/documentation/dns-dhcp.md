# DNS and DHCP

DNS translates names to addresses. DHCP supplies client network configuration.

Useful Windows checks:

```powershell
ipconfig /all
ipconfig /release
ipconfig /renew
ipconfig /flushdns
nslookup example.local
```
