# VLAN Basics

VLANs logically separate Layer 2 network segments.

Typical concepts:

- Access port
- Trunk port
- VLAN ID
- Inter-VLAN routing
- DHCP scope per subnet

Configuration should be tested in a controlled environment before production changes.
