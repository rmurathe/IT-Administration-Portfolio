# IP Addressing

Document:

- Network address
- Subnet mask/prefix
- Default gateway
- DNS servers
- DHCP range
- Static infrastructure addresses

Avoid duplicate IP addresses and keep an address-management record.
