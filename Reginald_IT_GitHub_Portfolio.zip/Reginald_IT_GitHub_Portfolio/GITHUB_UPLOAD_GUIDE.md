# GitHub Upload Guide

## Recommended Repository Structure

Create one GitHub repository for each project:

- `automated-network-backup-powershell`
- `windows-server-active-directory-lab`
- `network-administration-troubleshooting-lab`
- `smb-file-server-ntfs-permissions`
- `powershell-it-administration-automation`
- `vmware-windows-infrastructure-lab`
- `windows-desktop-troubleshooting-it-support`
- `it-documentation-infrastructure-procedures`

## Upload Method

For each project:

1. Sign in to GitHub.
2. Create a new repository using the project folder name.
3. Keep the repository public only after checking that no confidential information is present.
4. Upload the files from the corresponding project folder.
5. Commit the files.
6. Open the repository and confirm that `README.md` displays correctly.

## Before Publishing

Check for:

- Company names that should remain private
- Real server names
- Real IP addresses
- Usernames
- Passwords or credentials
- Private network paths
- Internal documents
- Customer information
- Personal information belonging to other people

## Profile README

If your GitHub username is configured for a profile README, use the contents of `PROFILE_README.md` as the profile README.

## Suggested CV Link

After publishing, add your GitHub profile URL to your CV under:

**Professional Portfolio:** GitHub – IT Infrastructure & Support Portfolio
