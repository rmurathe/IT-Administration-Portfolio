# Group Policy

Example policy areas:

- Password policy
- Windows security settings
- Desktop configuration
- Firewall settings
- Drive mappings
- Software configuration

Useful commands:

```powershell
gpupdate /force
gpresult /r
```

Test policies in a dedicated OU before broad deployment.
