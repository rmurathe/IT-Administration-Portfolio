# Active Directory Administration

## Core Tasks

- Create users and groups
- Organize users and computers with OUs
- Apply security groups
- Manage domain computers
- Review account status
- Troubleshoot domain membership

## Useful Commands

```powershell
Get-ADUser -Filter *
Get-ADComputer -Filter *
Get-ADGroup -Filter *
Get-ADOrganizationalUnit -Filter *
```

## Design Principle

Use OUs for administration and Group Policy scope, and security groups for access control where appropriate.
