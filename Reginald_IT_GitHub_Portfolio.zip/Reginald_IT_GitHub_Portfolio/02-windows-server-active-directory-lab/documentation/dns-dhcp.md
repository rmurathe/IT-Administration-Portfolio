# DNS and DHCP

## DNS

A domain environment depends on reliable name resolution.

Useful checks:

```powershell
nslookup corp.example.local
Get-DnsServerZone
```

## DHCP

Review scopes and leases:

```powershell
Get-DhcpServerv4Scope
Get-DhcpServerv4Lease -ScopeId 192.168.8.0
```

Use static addressing for infrastructure servers and planned DHCP ranges for clients.
