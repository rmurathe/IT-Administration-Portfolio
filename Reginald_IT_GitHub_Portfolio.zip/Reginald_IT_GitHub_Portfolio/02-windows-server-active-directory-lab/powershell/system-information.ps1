Get-CimInstance Win32_ComputerSystem |
    Select-Object Manufacturer, Model, Domain, NumberOfLogicalProcessors

Get-CimInstance Win32_OperatingSystem |
    Select-Object Caption, Version, BuildNumber, LastBootUpTime
