Import-Module ActiveDirectory

$Users = @(
    @{Name="Demo User 01"; SamAccountName="demouser01"; Department="Finance"},
    @{Name="Demo User 02"; SamAccountName="demouser02"; Department="Operations"}
)

foreach ($User in $Users) {
    Write-Host "Creating/checking $($User.SamAccountName)"
    Get-ADUser -Filter "SamAccountName -eq '$($User.SamAccountName)'" -ErrorAction SilentlyContinue
}
